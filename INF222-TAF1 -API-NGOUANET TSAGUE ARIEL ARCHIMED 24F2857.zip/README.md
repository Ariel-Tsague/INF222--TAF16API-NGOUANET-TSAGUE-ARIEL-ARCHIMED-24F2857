# API Blog - TAF 1 (INF222)

## Description
Ce projet contient la logique d'une API de gestion de blog développée avec Spring Boot.

## Structure
- Article.java : Modèle de données.
- ArticleRepository.java : Gestion de la base de données.
- ArticleController.java : Points d'entrée de l'API (Endpoints).

## Endpoints
- GET /api/articles : Liste tout.
- POST /api/articles : Créer un article.
- GET /api/articles/search?query=... : Rechercher par texte.
- DELETE /api/articles/{id} : Supprimer.

## Installation
Lancer avec la commande : mvn spring-boot:run