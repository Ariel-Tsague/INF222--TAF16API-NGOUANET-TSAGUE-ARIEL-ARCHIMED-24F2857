@GetMapping("/search")
public ResponseEntity<List<Article>> searchArticles(@RequestParam("query") String query) {
    // Si la recherche est vide, on pourrait renvoyer une erreur 400, 
    // mais je préfère renvoyer une liste vide pour ne pas faire planter l'interface.
    if (query == null || query.isEmpty()) {
        return ResponseEntity.ok(Collections.emptyList());
    }
    
    List<Article> resultats = articleRepository.findByTitreContainingIgnoreCaseOrContenuContainingIgnoreCase(query, query);
    return ResponseEntity.ok(resultats); // Code 200 par défaut ici
}