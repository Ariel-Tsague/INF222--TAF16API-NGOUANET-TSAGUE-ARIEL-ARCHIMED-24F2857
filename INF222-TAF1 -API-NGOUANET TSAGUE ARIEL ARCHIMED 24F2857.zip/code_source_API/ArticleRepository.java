// Ici, j'utilise une requête personnalisée. 
// "Containing" permet de chercher le mot n'importe où dans le texte (comme un moteur de recherche).
// "IgnoreCase" évite que la recherche échoue si l'utilisateur met des majuscules.
List<Article> findByTitreContainingIgnoreCaseOrContenuContainingIgnoreCase(String titre, String contenu);